document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    const uploadButton = document.getElementById('uploadBtn');


    uploadButton.addEventListener('click', function() {
        // Check if a file is selected
        if (fileInput.files.length > 0) {
            const formData = new FormData(uploadForm);

            fetch(uploadForm.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);  // Handle the response as needed
            })
            .catch(error => {
                console.error('Error:', error);
            });
        } else {
            alert('Please select a file before uploading.');
        }
    });
});
